#define F_CPU 8000000UL // 8 MHz Internal Oscillator

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdlib.h> // For abs() if needed

#include "usiTwiSlave.h"

// --- Configuration ---
#define SLAVE_ADDR 0x08
#define TEMP_ADC_CHANNEL 3 // ADC3 = PB3
#define HEATER_PIN PB4     // OC0B Output for Timer0 PWM

// I2C Commands (Master to Slave)
#define CMD_SET_SETPOINT 0x01
// (No specific command needed for reading temp, handled by onRequest)

// PID Parameters (MUST BE TUNED!)
#define PID_KP 2.0
#define PID_KI 0.5
#define PID_KD 1.0
#define PID_SAMPLE_TIME_MS 500 // How often to run PID loop

// ADC Config
#define ADC_REF_VOLTAGE 1.1 // Using internal 1.1V reference
#define ADC_MAX_VALUE 1023.0 // 10-bit ADC

// PID State Variables
volatile int8_t targetTemperature = 25; // Default target temp (°C)
volatile int8_t currentTemperature_int = 0;
volatile uint8_t currentTemperature_frac = 0; // Scaled by 100

float pid_error = 0;
float pid_integral = 0;
float pid_derivative = 0;
float pid_last_error = 0;
int16_t pid_output = 0; // Output for PWM (0-255)

// --- Function Prototypes ---
void setup_adc(void);
uint16_t read_adc(uint8_t channel);
void convert_adc_to_temp(uint16_t adc_value);
void setup_pwm(void);
void update_pid(void);
void i2c_receive_handler(uint8_t num_bytes);
void i2c_request_handler(void);

int main(void) {
    // --- Initialization ---
    setup_adc();
    setup_pwm(); // PWM Setup is called

    // Initialize I2C Slave
    usiTwiSlaveInit(SLAVE_ADDR);

    // Assign I2C callback handlers
    usi_onReceiverPtr = i2c_receive_handler;
    usi_onRequestPtr = i2c_request_handler;

    sei(); // Enable global interrupts

    // --- Main Loop ---
    uint8_t test_pwm_value = 128; // Start with 50% duty cycle test

    while (1) {
        // ***** DEBUGGING: Force PWM Output *****
        OCR0B = test_pwm_value; // Directly set the Output Compare Register
        // **************************************

        // ---- Temporarily disable sensor reading and PID for this test ----
        /*
        // Read temperature
        uint16_t adc_val = read_adc(TEMP_ADC_CHANNEL);
        convert_adc_to_temp(adc_val);

        // Update PID control
        update_pid();

        // Apply PID output to PWM
        if (pid_output < 0) {
            OCR0B = 0;
        } else if (pid_output > 255) {
            OCR0B = 255;
        } else {
            OCR0B = (uint8_t)pid_output;
        }
        */
       // ---- End of temporarily disabled code ----


        // Optional: Add a small delay if needed for observation,
        // but PWM should run continuously regardless.
        _delay_ms(100);

        // Optional: Vary the test value to see if it changes
        // test_pwm_value++; // Uncomment this line to see brightness/duty cycle ramp up

    }
}

// --- Function Definitions ---

void setup_adc(void) {
    // Select ADC channel 3 (PB3) - ADMUX already defaults to ADC0 if needed later
    // Select Voltage Reference: Internal 1.1V
    // Left Adjust Result: No (ADLAR=0)
    ADMUX = (1 << REFS1) | (0 << REFS0) | (0 << ADLAR) | (TEMP_ADC_CHANNEL & 0x0F);
        // For ATtiny85:
        // REFS1=1, REFS0=0 -> Internal 1.1V Ref
        // MUX bits select channel (0011 = ADC3 = PB3)

    // Enable ADC
    // Set ADC Prescaler: F_CPU / 64 = 8MHz / 64 = 125 kHz (within 50-200kHz range)
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (0 << ADPS0);
}

uint16_t read_adc(uint8_t channel) {
    // Select channel (redundant if only using one, but good practice)
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);

    // Start single conversion
    ADCSRA |= (1 << ADSC);

    // Wait for conversion to complete
    while (ADCSRA & (1 << ADSC));

    // Read the result (low byte first, then high byte)
    // Since ADLAR=0, read ADCL then ADCH
    // uint8_t low = ADCL;
    // uint8_t high = ADCH;
    // return (high << 8) | low;
    return ADCW; // Read ADC Word directly
}

void convert_adc_to_temp(uint16_t adc_value) {
    // Convert ADC reading to voltage
    float voltage = (adc_value / ADC_MAX_VALUE) * ADC_REF_VOLTAGE;

    // Convert voltage to temperature (°C) for TMP36
    float temp_c_float = (voltage - 0.5) * 100.0;

    // Store integer and fractional parts (scaled)
    currentTemperature_int = (int8_t)temp_c_float;
    // Ensure fractional part is positive and scaled correctly
    float frac_part = temp_c_float - currentTemperature_int;
    if (frac_part < 0) frac_part = 0; // Handle negative temps if needed
    currentTemperature_frac = (uint8_t)(frac_part * 100.0);

    // Basic bounds check (optional)
    if (currentTemperature_int < -40) currentTemperature_int = -40;
    if (currentTemperature_int > 125) currentTemperature_int = 125;
}


void setup_pwm(void) {
    // Configure PB4 (OC0B) as output
    DDRB |= (1 << HEATER_PIN);

    // Configure Timer0 for Fast PWM mode (Mode 3: WGM01=1, WGM00=1)
    // Set OC0B on Compare Match, clear OC0B at BOTTOM (non-inverting mode)
    // COM0B1=1, COM0B0=0
    // Use prescaler: clk/64 (CS02=0, CS01=1, CS00=1) -> PWM Freq = 8MHz / 64 / 256 = 488 Hz
    TCCR0A = (1 << COM0B1) | (0 << COM0B0) | (1 << WGM01) | (1 << WGM00);
    TCCR0B = (0 << WGM02) | (0 << CS02) | (1 << CS01) | (1 << CS00);

    // Start with PWM off
    OCR0B = 0;
}

void update_pid(void) {
    float current_temp_combined = currentTemperature_int + (currentTemperature_frac / 100.0);
    pid_error = (float)targetTemperature - current_temp_combined;

    // Integral term with anti-windup (basic clamping)
    pid_integral += pid_error * (PID_SAMPLE_TIME_MS / 1000.0); // Scale by time
    // Clamp integral to prevent windup (adjust range as needed)
    float max_integral = 100.0; // Example limit
    if (pid_integral > max_integral) pid_integral = max_integral;
    else if (pid_integral < -max_integral) pid_integral = -max_integral;


    // Derivative term
    pid_derivative = (pid_error - pid_last_error) / (PID_SAMPLE_TIME_MS / 1000.0); // Scale by time

    // Calculate PID Output
    pid_output = (int16_t)( (PID_KP * pid_error) +
                            (PID_KI * pid_integral) +
                            (PID_KD * pid_derivative) );

    // Store error for next iteration's derivative calculation
    pid_last_error = pid_error;
}

// --- I2C Handlers ---

// Called when the Master writes data to the Slave
void i2c_receive_handler(uint8_t num_bytes) {
    if (num_bytes < 1) {
        return; // Should not happen, but safety check
    }

    uint8_t command = usiTwiReceiveByte(); // Read the first byte (command)

    if (command == CMD_SET_SETPOINT) {
        if (num_bytes >= 2) { // Check if setpoint value was also sent
             uint8_t received_setpoint = usiTwiReceiveByte();
             // Basic validation (e.g., 0-100 °C range)
             if (received_setpoint <= 100) {
                 targetTemperature = (int8_t)received_setpoint;
                 // Reset PID integral when setpoint changes? Optional, can help stability.
                 // pid_integral = 0;
             }
        }
    }

    // Discard any extra bytes sent by the master for this command
    while(usiTwiAmountDataInReceiveBuffer() > 0) {
        usiTwiReceiveByte();
    }
}

// Called when the Master requests data from the Slave
void i2c_request_handler(void) {
    // Master wants the current temperature
    // Send Integer part first, then fractional part
    usiTwiTransmitByte((uint8_t)currentTemperature_int);
    usiTwiTransmitByte(currentTemperature_frac);
}